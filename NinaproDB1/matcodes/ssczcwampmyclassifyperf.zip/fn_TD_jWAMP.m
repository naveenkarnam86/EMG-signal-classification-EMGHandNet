%-------------------------------------------------------------------------%
%  Electromyography (EMG) Feature Extraction source codes demo version    %
%                                                                         %
%  Programmer: Jingwei Too                                                %
%                                                                         %
%  E-Mail: jamesjames868@gmail.com                                        %
%-------------------------------------------------------------------------%

function WA=fn_TD_jWAMP(data,thres)
WA=[];
[M,N]=size(data); 
for j=1:1:N
    d=0;
for k=1:M-1 
  if abs(data(k,j)-data(k+1,j)) >= thres
    d=d+1; 
  end
end
WA=[WA,d];
end
return

